package com.electricity.paf.Model;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.Statement;

import com.google.gson.JsonArray;
import com.google.gson.JsonObject;

import jakarta.ws.rs.core.Response;
import jakarta.ws.rs.core.Response.Status;

public class PowerDetails {

	private Connection connect() {
		Connection con = null;
		try {
			Class.forName("com.mysql.cj.jdbc.Driver");

			// Provide the correct details: DBServer/DBName, username, password
			con = DriverManager.getConnection(
					"jdbc:mysql://localhost:3306/electricity?useUnicode=true&useJDBCCompliantTimezoneShift=true&useLegacyDatetimeCode=false&serverTimezone=UTC",
					"root", "Optimize@4321");
		} catch (Exception e) {
			e.printStackTrace();
		}
		return con;
	}

	public String insertPowerDetails(String pdCusName, String pdAccNo, String psUnit, String pdDate, String pdPay) {
		String output = "";
		try {
			Connection con = connect();
			if (con == null) {
				return "Error while connecting to the database for inserting.";
			}
			// create a prepared statement
			String query = " insert into powermanage(`pdID`,`pdCusName`,`pdAccNo`,`psUnit`,`pdDate`,`pdPay`)"
					+ " values (?, ?, ?, ?, ?, ?)";
			PreparedStatement preparedStmt = con.prepareStatement(query);
			// binding values
			preparedStmt.setInt(1, 0);
			preparedStmt.setString(2, pdCusName);
			preparedStmt.setString(3, pdAccNo);
			preparedStmt.setString(4, psUnit);
			preparedStmt.setString(5, pdDate);
			preparedStmt.setString(6, pdPay);
			// execute the statement
			preparedStmt.execute();
			con.close();
			output = "Inserted successfully";
		} catch (Exception e) {
			output = "Error while inserting the Power Details.";
			System.err.println(e.getMessage());
		}
		return output;
	}

	public Response readPowerDetails() {
		//String output = "";'
		JsonObject obj = new JsonObject();
		JsonArray jsArray = new JsonArray();
		obj.addProperty("state","1");
		try {
			Connection con = connect();
			if (con == null) {
				obj.add("data", jsArray);
				obj.addProperty("message", "Error while connecting to the database for reading.");
				
				Response  response = Response.status(Status.OK).entity(obj.toString()).header("Access-Control-Allow-Origin", "*")
						.header("Access-Control-Allow-Methods", "GET, POST, DELETE, PUT")
						.allow("OPTIONS").build();
				
				return response;
			}
			// Prepare the html table to be displayed
			//output = "<table border=\"1\"><tr><th>Customer Name</th><th>Account No</th><th>Unit Amount</th><th>Date</th><th>Total Price </th></tr>";
			String query = "select * from powermanage";
			Statement stmt = (Statement) con.createStatement();
			ResultSet rs = ((java.sql.Statement) stmt).executeQuery(query);
			// iterate through the rows in the result set
			while (rs.next()) {
				JsonObject objs = new JsonObject();
				String pdID = Integer.toString(rs.getInt("pdID"));
				String pdCusName = rs.getString("pdCusName");
				String pdAccNo = rs.getString("pdAccNo");
				String psUnit = rs.getString("psUnit");
				String pdDate = rs.getString("pdDate");
				String pdPay = rs.getString("pdPay");

				// Add into the html table
				objs.addProperty("pID",pdID );
				objs.addProperty("pdCusName",pdCusName );
				objs.addProperty("pdAccNo", pdAccNo);
				objs.addProperty("psUnit", psUnit);
				objs.addProperty("pdDate", pdDate);
				objs.addProperty("pdPay", pdPay);
				
				jsArray.add(objs);
				
			}
			con.close();
			obj.add("data", jsArray);
			obj.addProperty("message", "Succesfully get all payemt info !");
		} catch (Exception e) {
			obj.addProperty("message", e.getMessage());
			System.err.println(e.getMessage());
		}
		Response  response = Response.status(Status.OK).entity(obj.toString()).header("Access-Control-Allow-Origin", "*")
				.header("Access-Control-Allow-Methods", "GET, POST, DELETE, PUT")
				.allow("OPTIONS").build();
		
		return response;
	}

	public String updatePowerDetails(String pdID, String pdCusName, String pdAccNo, String psUnit, String pdDate, String pdPay) {
		String output = "";

		try {
			Connection con = connect();

			if (con == null) {
				return "Error while connecting to the database for updating.";
			}

			// create a prepared statement
			String query = "UPDATE powermanage SET pdCusName=?,pdAccNo=?,psUnit=?,pdDate=?,pdPay=?" + "WHERE pdID=?";

			PreparedStatement preparedStmt = con.prepareStatement(query);

			// binding values
			preparedStmt.setString(1, pdCusName);
			preparedStmt.setString(2, pdAccNo);
			preparedStmt.setString(3, psUnit);
			preparedStmt.setString(4, pdDate);
			preparedStmt.setString(5, pdPay);
			preparedStmt.setInt(6, Integer.parseInt(pdID));

			// execute the statement
			preparedStmt.execute();
			con.close();

			output = "Updated successfully";
		} catch (Exception e) {
			output = "Error while updating the Power Details.";
			System.err.println(e.getMessage());
		}

		return output;
	}

	public String deletePowerDetails(String pdID) {
		String output = "";

		try {
			Connection con = connect();

			if (con == null) {
				return "Error while connecting to the database for deleting.";
			}

			// create a prepared statement
			String query = "delete from powermanage where pdID=?";

			PreparedStatement preparedStmt = con.prepareStatement(query);

			// binding values
			preparedStmt.setInt(1, Integer.parseInt(pdID));

			// execute the statement
			preparedStmt.execute();
			con.close();

			output = "Deleted successfully";
		} catch (Exception e) {
			output = "Error while deleting the Power Details.";
			System.err.println(e.getMessage());
		}

		return output;
	}
	
}
