package com.electricity.paf.Model;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.Statement;

import com.google.gson.JsonArray;
import com.google.gson.JsonObject;

import jakarta.ws.rs.core.Response;
import jakarta.ws.rs.core.Response.Status;

public class Payment {

	private Connection connect() {
		Connection con = null;
		try {
			Class.forName("com.mysql.cj.jdbc.Driver");

			// Provide the correct details: DBServer/DBName, username, password
			con = DriverManager.getConnection(
					"jdbc:mysql://localhost:3306/electricity?useUnicode=true&useJDBCCompliantTimezoneShift=true&useLegacyDatetimeCode=false&serverTimezone=UTC",
					"root", "Optimize@4321");
		} catch (Exception e) {
			e.printStackTrace();
		}
		return con;
	}
	public String insertPayment(String pAccNo, String pCus, String pDate, String pAmount) {
		String output = "";
		try {
			Connection con = connect();
			if (con == null) {
				return "Error while connecting to the database for inserting.";
			}
			// create a prepared statement
			String query = " insert into paymanage(`pID`,`pAccNo`,`pCus`,`pDate`,`pAmount`)" + " values (?, ?, ?, ?, ?)";
			PreparedStatement preparedStmt = con.prepareStatement(query);
			// binding values
			preparedStmt.setInt(1, 0);
			preparedStmt.setString(2, pAccNo);
			preparedStmt.setString(3, pCus);
			preparedStmt.setString(4, pDate);
			preparedStmt.setString(5, pAmount);

			// execute the statement
			preparedStmt.execute();
			con.close();
			output = "Inserted successfully";
		} catch (Exception e) {
			output = "Error while inserting the Payment.";
			System.err.println(e.getMessage());
		}
		return output;
	}

	public Response readPayment() {
		JsonObject obj = new JsonObject();
		JsonArray jsArray = new JsonArray();
		obj.addProperty("state","1");
		try {
			Connection con = connect();
			if (con == null) {
				
				obj.add("data", jsArray);
				obj.addProperty("message", "Error while connecting to the database for reading.");
				
				Response  response = Response.status(Status.OK).entity(obj.toString()).build();
				
				return response;
			}
			// Prepare the html table to be displayed
			//output = "<table><th class=\"border-0\">#</th><th class=\"border-0\">Payment Id</th><th class=\"border-0\">Account Number</th><th class=\"border-0\">Coustomer</th><th class=\"border-0\">Date</th><th class=\"border-0\">Amount</th> <th class=\"border-0\">Update</th><th class=\"border-0\">Delete</th>";
			String query = "select * from paymanage";
			Statement stmt = (Statement) con.createStatement();
			ResultSet rs = ((java.sql.Statement) stmt).executeQuery(query);
			// iterate through the rows in the result set
			while (rs.next()) {
				JsonObject objs = new JsonObject();
				String pID = Integer.toString(rs.getInt("pID"));
				String pAccNo = rs.getString("pAccNo");
				String pCus = rs.getString("pCus");
				String pDate = rs.getString("pDate");
				String pAmount = Float.toString(rs.getFloat("pAmount"));
				
				objs.addProperty("pID",pID );
				objs.addProperty("pAccNo",pAccNo );
				objs.addProperty("pCus", pCus);
				objs.addProperty("pDate", pDate);
				objs.addProperty("pAmount", pAmount);
				
				jsArray.add(objs);
			}
			con.close();
			
			obj.add("data", jsArray);
			obj.addProperty("message", "Succesfully get all payemt info !");
			
			//output += "</table>";
		} catch (Exception e) {
			obj.addProperty("message", e.getMessage());
			System.err.println(e.getMessage());
		}
		Response  response = Response.status(Status.OK).entity(obj.toString()).build();
		
		return response;
	}

	public String updatePayment(String pID, String pAccNo,String pCus, String pDate, String pAmount) {
		String output = "";

		try {
			Connection con = connect();

			if (con == null) {
				return "Error while connecting to the database for updating.";
			}

			// create a prepared statement
			String query = "UPDATE paymanage SET pAccNo=?,pCus=?,pDate=?,pAmount=? WHERE pID=?";

			PreparedStatement preparedStmt = con.prepareStatement(query);

			// binding values

			preparedStmt.setString(1, pAccNo);
			preparedStmt.setString(2, pCus);
			preparedStmt.setString(3, pDate);
			preparedStmt.setString(4, pAmount);
			preparedStmt.setInt(5, Integer.parseInt(pID));
			

			// execute the statement
			preparedStmt.execute();
			con.close();

			output = "Updated successfully";
		} catch (Exception e) {
			output = "Error while updating the Payment.";
			System.err.println(e.getMessage());
		}

		return output;
	}

	public String deletePayment(String pID) {

		String output = "";

		try {
			Connection con = connect();

			if (con == null) {
				return "Error while connecting to the database for deleting.";
			}

			// create a prepared statement
			String query = "delete from paymanage where pID=?";

			PreparedStatement preparedStmt = con.prepareStatement(query);

			// binding values
			preparedStmt.setInt(1, Integer.parseInt(pID));

			// execute the statement
			preparedStmt.execute();
			con.close();

			output = "Deleted successfully";
		} catch (Exception e) {
			output = "Error while deleting the Payment.";
			System.err.println(e.getMessage());
		}

		return output;
	}
	
}
