$(function() {

    getBillsInfo();
    
    });
const addPowerDetails = (e) => {

    e.preventDefault();

    Swal.fire({
        title: 'Are you sure?',
        text: "You won't be able to revert this!",
        icon: 'warning',
        showCancelButton: true,
        confirmButtonColor: '#3085d6',
        cancelButtonColor: '#d33',
        confirmButtonText: 'Yes, Save it!'
    }).then((result) => {
        if (result.isConfirmed) {
            const pod_nam = $("#pod_nam").val();
            const pod_accnum = $("#pod_accnum").val();
            const pod_uni = $("#pod_uni").val();
            const pod_date = $("#pod_date").val();
            const pod_pay = $("#pod_pay").val();


            //add bill api

            $.ajax({
                type: "POST",
                headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
                data: `pdCusName=+${encodeURIComponent(pod_nam)}`+`&pdAccNo=+${encodeURIComponent(pod_accnum)}`+`&psUnit=+${encodeURIComponent(pod_uni)}`+`&pdDate=+${encodeURIComponent(pod_date)}`+`&pdPay=+${encodeURIComponent(pod_pay )}`,
                url: "http://localhost:8090/API/webapi/API/addPowerDetailsInfo",
                success: function (data) {
                    console.log(data);
                    if (data) {
                        Swal.fire(
                            'Successful!',
                            'Power Details Saved!',
                            'success'
                        );
                        clearForm();
                    } else {
                        Swal.fire(
                            'Error!',
                            'Unable to save!',
                            'error'
                        );
                    }


                }
            });
        }
    })
}

const updatePowerDetails = (e) => {

    e.preventDefault();

    Swal.fire({
        title: 'Are you sure?',
        text: "You won't be able to revert this!",
        icon: 'warning',
        showCancelButton: true,
        confirmButtonColor: '#3085d6',
        cancelButtonColor: '#d33',
        confirmButtonText: 'Yes, Save it!'
    }).then((result) => {
        if (result.isConfirmed) {
            const pod_num = $("#pod_id").val();
            const pod_nam = $("#pod_nam").val();
            const pod_accnum = $("#pod_accnum").val();
            const pod_uni = $("#pod_uni").val();
            const pod_date = $("#pod_date").val();
            const pod_pay = $("#pod_pay").val();


            //add power api

            $.ajax({
                type: "POST",
                headers: {'Content-Type': 'application/x-www-form-urlencoded'},
                data: $.param({pdID: pod_num,pdCusName: pod_nam, pdAccNo : pod_accnum,psUnit: pod_uni,pdDate:pod_date,pdPay: pod_pay}),
                url: "http://localhost:8090/API/webapi/API/updatePowerDetailsInfo",
                success: function (data) {
                    console.log(data);
                    if (data) {
                        Swal.fire(
                            'Successful!',
                            'Power Details Saved!',
                            'success'
                        );
                        clearForm();
                        $("#addBtn").show();
                        $("updateBtn").hide();
                    } else {
                        Swal.fire(
                            'Error!',
                            'Unable to save!',
                            'error'
                        );
                    }


                }
            });
        }
    })
}

const getBillsInfo = () => {
    $.ajax({
		type: "GET",
		url: "http://localhost:8090/API/webapi/API/getAllPowerDetails",
		headers: {'Content-Type': 'application/x-www-form-urlencoded'},
		//data: $.param({username: $scope.userName, password: $scope.password}),
		success: function (data) {
			 
			$('#tblViewpowermanage > tbody').html('');
            $.each(data.data, function (i, bill) {
				appenpowermanageTable(bill);
			});
			
		}
	});
}

const appenpowermanagetTable = (item) => {
	
	let textToInsert = '';
	textToInsert += addRow(item);
	$('#tblViewpowermanage > tbody').append(textToInsert);
};

const addRow = (item) => {
	
	const delete_btn = '<button type="button" class="btn btn-danger btn-xs" id="' + item.pdID + 'delete" onclick="removepowerdetails(\'' + item.pdID+ '\')"><span class="fas fa-trash-alt"></span>&nbsp;Delete Power details</button>';
	
    
    const update_btn = '<button type="button" class="btn btn-waring btn-xs" id="' + item.pdID + 'delete" onclick="setUpdateData(\'' + item.pdID+'\',\''+item.pdCusName+ '\',\''+item.pdAccNo+'\',\''+item.psUnit+'\',\''+item.pdDate+'\',\'' + item.pdPay+'\')"><span class="fas fa-edit"></span>&nbsp;Edit Power details</button>';
	

	let row = '<tr id="' + item.pdID + '">'
        + '<td>' + item.pdID + '</td>'
		+ '<td>' + item.pdCusName + '</td>'
		+ '<td>' + item.pdAccNo + '</td>'
        + '<td>' + item.psUnit + '</td>'
		+ '<td>' + item.pdDate + '</td>'
		+ '<td>' + item.pdPay + '</td>' 
		+ '<td>'
			+ update_btn
		+ '</td>'
		+ '<td>'
			+ delete_btn
		+ '</td>'
		+ '</tr>';
	return row;
};


const setUpdateDate=(pod_num,pod_nam ,pod_accnum,pod_uni,pod_date,pod_pay)=>{

     $("#pod_id").val(pod_num);
     $("#pod_nam").val(pod_nam);
     $("#pod_accnum").val(pod_accnum);
     $("#pod_uni").val(pod_uni);
     $("#pod_date").val(pod_date);
     $("#pod_pay").val(pod_pay);


    $("#addBtn").hide();
    $("updateBtn").show();
}

const removepowermanage = (ids) => {

    // e.preventDefault();

    Swal.fire({
        title: 'Are you sure?',
        text: "You won't be able to revert this!",
        icon: 'warning',
        showCancelButton: true,
        confirmButtonColor: '#3085d6',
        cancelButtonColor: '#d33',
        confirmButtonText: 'Yes, Save it!'
    }).then((result) => {
        if (result.isConfirmed) {
            const pod_num = ids;

            //add 

            $.ajax({
                type: "POST",
                headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
                data: `paymentData=+${encodeURIComponent(pod_num)}`,
                url: "http://localhost:8090/API/webapi/API/removePowerDetails",
                success: function (data) {
                    console.log(data);
                    if (data) {
                        Swal.fire(
                            'Successful!',
                            'Power Details Removed!',
                            'success'
                        );
                        clearForm();
                        getBillsInfo();
                    } else {
                        Swal.fire(
                            'Error!',
                            'Unable to remove!',
                            'error'
                        );
                    }


                }
            });
        }
    })
}

